
 

#ifndef _ENDIAN_H_
#define _ENDIAN_H_

#define __LITTLE_ENDIAN 1234
#define __BIG_ENDIAN    4321

#define __BYTE_ORDER    __LITTLE_ENDIAN

#endif /* _ENDIAN_H_ */
