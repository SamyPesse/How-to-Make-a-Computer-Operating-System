

#ifndef _SYS_CDEFS_H_
#define _SYS_CDEFS_H_

#define __nonnull(params) __attribute__((__nonnull__ params))

#endif // _SYS_CDEFS_H_
