
 

#include <termios.h>

int tcflush( int fd, int queue_selector ) {
    return 0;
}
