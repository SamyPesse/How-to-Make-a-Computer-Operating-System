#include <unistd.h>

int setpgrp( void ) {
    return 0;
}
