#include <unistd.h>

int setgid( gid_t gid ) {
    return 0;
}

