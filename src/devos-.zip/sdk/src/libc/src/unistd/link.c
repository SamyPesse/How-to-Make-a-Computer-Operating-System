#include <unistd.h>


int link( const char* oldpath, const char* newpath ) {
    /* TODO */

    printf( "TODO: link() not yet implemented!\n" );

    return 0;
}
